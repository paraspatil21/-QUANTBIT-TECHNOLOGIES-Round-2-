# role/role.py
class Role:
    def __init__(self, title, permissions, salary_grade):
        self.title = title
        self.permissions = permissions
        self.salary_grade = salary_grade

    def to_dict(self):
        return {
            "title": self.title,
            "permissions": self.permissions,
            "salary_grade": self.salary_grade
        }