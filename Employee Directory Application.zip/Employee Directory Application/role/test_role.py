# role/test_role.py
import unittest
from role.role import Role

class TestRole(unittest.TestCase):
    def test_role_creation(self):
        role = Role("Manager", ["approve_leave", "manage_team"], "B")
        self.assertEqual(role.title, "Manager")
        self.assertIn("approve_leave", role.permissions)

if __name__ == '__main__':
    unittest.main()