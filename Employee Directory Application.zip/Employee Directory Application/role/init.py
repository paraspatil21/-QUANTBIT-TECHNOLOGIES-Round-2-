# role/__init__.py
from .role import Role