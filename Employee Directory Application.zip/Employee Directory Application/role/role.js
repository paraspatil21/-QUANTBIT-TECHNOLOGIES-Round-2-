// role/role.js
class RoleController {
    constructor() {
        this.form = document.querySelector('#role-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const roleData = Object.fromEntries(formData.entries());
        console.log('Role Data:', roleData);
    }
}

new RoleController();