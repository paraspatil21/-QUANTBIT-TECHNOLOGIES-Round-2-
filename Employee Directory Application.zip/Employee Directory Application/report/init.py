# report/__init__.py
from .report import Report