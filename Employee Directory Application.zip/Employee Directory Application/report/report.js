// report/report.js
class ReportController {
    constructor() {
        this.form = document.querySelector('#report-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const reportData = Object.fromEntries(formData.entries());
        console.log('Report Parameters:', reportData);
    }
}

new ReportController();