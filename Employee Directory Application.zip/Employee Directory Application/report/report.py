# report/test_report.py
import unittest
from report.report import Report

class TestReport(unittest.TestCase):
    def test_report_generation(self):
        report = Report("Attendance", {"start_date": "2024-01-01"})
        result = report.generate()
        self.assertIn("Attendance", result["report_type"])

if __name__ == '__main__':
    unittest.main()