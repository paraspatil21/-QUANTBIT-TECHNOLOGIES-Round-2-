// attendance/attendance.js
class AttendanceController {
    constructor() {
        this.form = document.querySelector('#attendance-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const attendanceData = Object.fromEntries(formData.entries());
        console.log('Attendance Data:', attendanceData);
    }
}

new AttendanceController();