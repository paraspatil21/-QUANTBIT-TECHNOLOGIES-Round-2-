# attendance/__init__.py
from .attendance import Attendance