# attendance/test_attendance.py
import unittest
from datetime import date
from attendance.attendance import Attendance

class TestAttendance(unittest.TestCase):
    def test_attendance_creation(self):
        att = Attendance(1001, date.today(), "Present")
        self.assertEqual(att.employee_id, 1001)
        self.assertEqual(att.status, "Present")

if __name__ == '__main__':
    unittest.main()