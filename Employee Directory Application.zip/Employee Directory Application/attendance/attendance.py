# attendance/attendance.py
from datetime import date

class Attendance:
    def __init__(self, employee_id, date, status):
        self.employee_id = employee_id
        self.date = date
        self.status = status

    def to_dict(self):
        return {
            "employee_id": self.employee_id,
            "date": self.date.isoformat(),
            "status": self.status
        }