// training/training.js
class TrainingController {
    constructor() {
        this.form = document.querySelector('#training-form');
        this.participantList = document.querySelector('#participant-list');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', this.handleSubmit.bind(this));
        document.querySelector('#add-participant').addEventListener('click', this.addParticipantField.bind(this));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const trainingData = {
            name: formData.get('name'),
            trainer: formData.get('trainer_id'),
            startDate: formData.get('start_date'),
            endDate: formData.get('end_date'),
            participants: Array.from(formData.getAll('participants'))
        };
        console.log('Training Program Data:', trainingData);
    }

    addParticipantField() {
        const newField = document.createElement('input');
        newField.type = 'text';
        newField.name = 'participants';
        newField.placeholder = 'Employee ID';
        this.participantList.appendChild(newField);
    }
}

new TrainingController();