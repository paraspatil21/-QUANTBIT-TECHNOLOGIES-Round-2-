# training/test_training.py
import unittest
from datetime import date
from training.training import TrainingProgram

class TestTraining(unittest.TestCase):
    def test_program_creation(self):
        start_date = date(2024, 6, 1)
        end_date = date(2024, 6, 5)
        program = TrainingProgram("Python Basics", "E001", start_date, end_date)
        
        self.assertEqual(program.name, "Python Basics")
        self.assertEqual(program.duration_days, 4)

    def test_participant_management(self):
        program = TrainingProgram("Leadership", "E002", date(2024, 7, 1), date(2024, 7, 3))
        program.add_participant("E101")
        program.add_participant("E102")
        self.assertEqual(len(program.participants), 2)
        
        program.remove_participant("E101")
        self.assertEqual(len(program.participants), 1)

if __name__ == '__main__':
    unittest.main()