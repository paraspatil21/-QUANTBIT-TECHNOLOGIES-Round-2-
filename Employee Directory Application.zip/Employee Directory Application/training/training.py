# training/training.py
from datetime import date

class TrainingProgram:
    def __init__(self, name, trainer_id, start_date, end_date):
        self.name = name
        self.trainer_id = trainer_id
        self.start_date = start_date
        self.end_date = end_date
        self.participants = []
        self.program_id = f"TRN-{start_date.strftime('%Y%m')}-{id(self)}"

    def add_participant(self, employee_id):
        if employee_id not in self.participants:
            self.participants.append(employee_id)

    def remove_participant(self, employee_id):
        if employee_id in self.participants:
            self.participants.remove(employee_id)

    def to_dict(self):
        return {
            "program_id": self.program_id,
            "name": self.name,
            "trainer_id": self.trainer_id,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "participants": self.participants,
            "duration_days": (self.end_date - self.start_date).days
        }