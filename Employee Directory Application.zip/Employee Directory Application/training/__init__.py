# training/__init__.py
from .training import TrainingProgram