# employee/__init__.py
from .employee import Employee