// employee/employee.js
class EmployeeController {
    constructor() {
        this.form = document.querySelector('#employee-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const employeeData = Object.fromEntries(formData.entries());
        console.log('Employee Data:', employeeData);
    }
}

new EmployeeController();