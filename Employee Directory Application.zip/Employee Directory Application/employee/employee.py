# employee/employee.py
class Employee:
    def __init__(self, name, emp_id, department, role):
        self.name = name
        self.emp_id = emp_id
        self.department = department
        self.role = role

    def to_dict(self):
        return {
            "name": self.name,
            "emp_id": self.emp_id,
            "department": self.department,
            "role": self.role
        }