# employee/test_employee.py
import unittest
from employee.employee import Employee

class TestEmployee(unittest.TestCase):
    def test_employee_creation(self):
        emp = Employee("Arjun Patil", 1001, "HR", "Manager")
        self.assertEqual(emp.name, "Arjun Patil")
        self.assertEqual(emp.emp_id, 1001)

if __name__ == '__main__':
    unittest.main()