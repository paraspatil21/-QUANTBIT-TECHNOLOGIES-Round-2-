# leave/test_leave.py
import unittest
from datetime import date
from leave.leave import Leave

class TestLeave(unittest.TestCase):
    def test_leave_creation(self):
        leave = Leave(1001, date(2024, 1, 1), date(2024, 1, 5), "Vacation")
        self.assertEqual(leave.type, "Vacation")
        self.assertEqual(leave.status, "Pending")

if __name__ == '__main__':
    unittest.main()