# leave/leave.py
from datetime import date

class Leave:
    def __init__(self, employee_id, start_date, end_date, type, status="Pending"):
        self.employee_id = employee_id
        self.start_date = start_date
        self.end_date = end_date
        self.type = type
        self.status = status

    def to_dict(self):
        return {
            "employee_id": self.employee_id,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "type": self.type,
            "status": self.status
        }