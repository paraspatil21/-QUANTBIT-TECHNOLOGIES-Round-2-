// leave/leave.js
class LeaveController {
    constructor() {
        this.form = document.querySelector('#leave-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const leaveData = Object.fromEntries(formData.entries());
        console.log('Leave Data:', leaveData);
    }
}

new LeaveController();