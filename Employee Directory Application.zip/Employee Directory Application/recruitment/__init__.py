# recruitment/__init__.py
from .recruitment import JobApplication