# recruitment/test_recruitment.py
import unittest
from datetime import date
from recruitment.recruitment import JobApplication

class TestRecruitment(unittest.TestCase):
    def test_application_creation(self):
        app = JobApplication("Software Engineer", "John Doe")
        self.assertEqual(app.applicant_name, "John Doe")
        self.assertEqual(app.status, "Applied")
        self.assertEqual(app.application_date, date.today())

    def test_status_update(self):
        app = JobApplication("Data Analyst", "Jane Smith")
        app.update_status("Interviewed")
        self.assertEqual(app.status, "Interviewed")
        with self.assertRaises(ValueError):
            app.update_status("Invalid Status")

if __name__ == '__main__':
    unittest.main()