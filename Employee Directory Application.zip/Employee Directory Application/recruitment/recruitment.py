# recruitment/recruitment.py
from datetime import date

class JobApplication:
    def __init__(self, position, applicant_name, status="Applied"):
        self.position = position
        self.applicant_name = applicant_name
        self.status = status
        self.application_date = date.today()
        self.application_id = f"APP-{date.today().strftime('%Y%m%d')}-{id(self)}"

    def update_status(self, new_status):
        valid_statuses = ["Applied", "Interviewed", "Hired", "Rejected"]
        if new_status in valid_statuses:
            self.status = new_status
        else:
            raise ValueError("Invalid status")

    def to_dict(self):
        return {
            "application_id": self.application_id,
            "position": self.position,
            "applicant_name": self.applicant_name,
            "status": self.status,
            "application_date": self.application_date.isoformat()
        }