// recruitment/recruitment.js
class RecruitmentController {
    constructor() {
        this.form = document.querySelector('#recruitment-form');
        this.statusSelector = document.querySelector('#application-status');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', this.handleSubmit.bind(this));
        this.statusSelector.addEventListener('change', this.handleStatusChange.bind(this));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const applicationData = {
            position: formData.get('position'),
            applicantName: formData.get('applicant_name'),
            status: formData.get('status')
        };
        console.log('Submitting Application:', applicationData);
        // Add API call here
    }

    handleStatusChange(event) {
        console.log('Status updated to:', event.target.value);
    }
}

new RecruitmentController();