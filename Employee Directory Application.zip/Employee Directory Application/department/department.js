// department/department.js
class DepartmentController {
    constructor() {
        this.form = document.querySelector('#department-form');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(event) {
        event.preventDefault();
        const formData = new FormData(this.form);
        const departmentData = Object.fromEntries(formData.entries());
        console.log('Department Data:', departmentData);
    }
}

new DepartmentController();