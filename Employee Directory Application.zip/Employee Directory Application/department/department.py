# department/department.py
class Department:
    def __init__(self, name, manager, location):
        self.name = name
        self.manager = manager
        self.location = location

    def to_dict(self):
        return {
            "name": self.name,
            "manager": self.manager,
            "location": self.location
        }