# department/__init__.py
from .department import Department