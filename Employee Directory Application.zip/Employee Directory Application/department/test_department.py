# department/test_department.py
import unittest
from department.department import Department

class TestDepartment(unittest.TestCase):
    def test_department_creation(self):
        dept = Department("HR", "Jane Smith", "Floor 5")
        self.assertEqual(dept.name, "HR")
        self.assertEqual(dept.manager, "Jane Smith")

if __name__ == '__main__':
    unittest.main()